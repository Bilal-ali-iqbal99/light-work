package com.example.airbnb_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
