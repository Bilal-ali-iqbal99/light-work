import 'package:get/get.dart';

class HomeViewModel extends GetxController{

  RxInt bottomBarIndex = 0.obs;

}