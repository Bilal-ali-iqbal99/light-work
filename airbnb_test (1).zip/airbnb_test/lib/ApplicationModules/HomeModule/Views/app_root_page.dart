import 'package:airbnb_test/ApplicationModules/Utils/spaces.dart';
import 'package:fluentui_system_icons/fluentui_system_icons.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../ViewModels/home_view_model.dart';
import 'home_view.dart';

class AppRootPage extends StatelessWidget {
  AppRootPage({super.key});

  HomeViewModel homeViewModel = Get.put(HomeViewModel());

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => Scaffold(
        body: [
          HomeView(),
          Center(child: Icon(FluentIcons.heart_12_regular)),
          Center(child: Icon(FluentIcons.predictions_20_regular)),
          Center(child: Icon(FluentIcons.chat_12_regular)),
          Center(child: Icon(FluentIcons.person_12_regular)),
        ].elementAt(homeViewModel.bottomBarIndex.value),
        bottomNavigationBar: Container(
          height: 75,
          child: BottomNavigationBar(
            items: [
              BottomNavigationBarItem(
                icon: Icon(FluentIcons.search_12_regular),
                label: "Explore",
              ),
              BottomNavigationBarItem(
                icon: Icon(FluentIcons.heart_12_regular),
                label: "Wishlists",
              ),
              BottomNavigationBarItem(
                icon: Icon(FluentIcons.predictions_20_regular),
                label: "Tips",
              ),
              BottomNavigationBarItem(
                icon: Icon(FluentIcons.chat_12_regular),
                label: "Inbox",
              ),
              BottomNavigationBarItem(
                icon: Icon(FluentIcons.person_12_regular),
                label: "Profile",
              ),
            ],
            currentIndex: homeViewModel.bottomBarIndex.value,
            showSelectedLabels: true,
            showUnselectedLabels: true,
            selectedItemColor: Colors.pink,
            unselectedItemColor: Colors.grey,
            onTap: (index) {
              homeViewModel.bottomBarIndex.value = index;
            },
          ),
        ),

      ),
    );
  }
}
