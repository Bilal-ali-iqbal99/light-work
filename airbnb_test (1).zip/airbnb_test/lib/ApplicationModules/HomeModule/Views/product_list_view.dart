import 'package:airbnb_test/ApplicationModules/HomeModule/Views/Components/product_list_item.dart';
import 'package:flutter/material.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:sliding_up_panel2/sliding_up_panel2.dart';

class ProductsListView extends StatelessWidget {
  const ProductsListView({super.key});

  @override
  Widget build(BuildContext context) {
    // return ListView.builder(
    //   padding: EdgeInsets.all(16),
    //   itemCount: 10,
    //   itemBuilder: (context, index) {
    //     return ProductListItem();
    //   },
    // );
    return SlidingUpPanel(
      disableDraggableOnScrolling: true,
      body: Container(),
      panelBuilder: () {
        return ListView.builder(
          padding: EdgeInsets.all(16),
          itemCount: 10,
          itemBuilder: (context, index) {
            return ProductListItem();
          },
        );;
      },
    );
  }
}
