import 'package:airbnb_test/ApplicationModules/Utils/spaces.dart';
import 'package:flutter/material.dart';
import 'package:flutter_image_slideshow/flutter_image_slideshow.dart';
import 'package:optimized_cached_image/optimized_cached_image.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class ProductListItem extends StatelessWidget {
  ProductListItem({super.key});

  List<String> images = [
    "https://i.pinimg.com/236x/51/f3/a1/51f3a1668c9790689ca0063eb7bcedcb.jpg",
    "https://i.pinimg.com/236x/ee/b1/7b/eeb17be12572b7eada0b253eba140db0.jpg",
    "https://i.pinimg.com/236x/5c/8b/24/5c8b242f1e21d179f9bbf9ee1a88b173.jpg",
    "https://i.pinimg.com/236x/b0/a5/04/b0a50450832419e22edede3f4adacacf.jpg",
    "https://i.pinimg.com/236x/8a/ae/cf/8aaecfc58979d0ef701f09fc26d58bc0.jpg",
    "https://i.pinimg.com/236x/89/16/b9/8916b94c3339716f96a2f8c802f92be7.jpg",
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 35.h,
            width: 100.w,
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Stack(
              children: [
                Positioned(
                  top: 0,
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: ImageSlideshow(
                      width: 100.w,
                      initialPage: 0,
                      indicatorColor: Colors.white,
                      indicatorBackgroundColor: Colors.white.withOpacity(0.6),
                      children: List.generate(
                        images.length,
                        (index) => OptimizedCacheImage(
                          imageUrl: images[index],
                          fit: BoxFit.cover,
                          progressIndicatorBuilder:
                              (context, url, downloadProgress) {
                            return Center(
                              child: CircularProgressIndicator(
                                value: downloadProgress.progress,
                                color: Colors.white,
                              ),
                            );
                          },
                          errorWidget: (context, url, error) {
                            return Icon(
                              Icons.error,
                              color: Colors.white,
                            );
                          },
                        ),
                      ),
                      // autoPlayInterval: 5000,
                      isLoop: true,
                    ),
                  ),
                ),
                Positioned(
                  right: 8,
                  top: 8,
                  child: IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.favorite_border,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
          10.height,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Titonia, Idaho",
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                ),
              ),
              Row(
                children: [
                  Text(
                    "4.97",
                    style: TextStyle(
                      fontWeight: FontWeight.normal,
                      fontSize: 15,
                    ),
                  ),
                  3.width,
                  Icon(
                    Icons.star,
                    size: 18,
                  ),
                ],
              ),
            ],
          ),
          Text(
            "Jul 1-8",
            style: TextStyle(
              fontWeight: FontWeight.normal,
              fontSize: 14,
              color: Colors.black.withOpacity(0.7),
            ),
          ),
          8.height,
          Row(
            children: [
              Text(
                "\$89",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  color: Colors.black.withOpacity(0.7),
                ),
              ),
              6.width,
              Text(
                "night",
                style: TextStyle(
                  fontWeight: FontWeight.normal,
                  fontSize: 14,
                  color: Colors.black.withOpacity(0.7),
                ),
              ),
            ],
          ),
          16.height,
        ],
      ),
    );
  }
}
