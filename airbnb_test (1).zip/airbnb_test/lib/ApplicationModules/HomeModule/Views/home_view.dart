import 'package:airbnb_test/ApplicationModules/HomeModule/Views/Components/product_list_item.dart';
import 'package:airbnb_test/ApplicationModules/HomeModule/Views/product_list_view.dart';
import 'package:airbnb_test/ApplicationModules/MapsModule/Views/map_view.dart';
import 'package:airbnb_test/ApplicationModules/Utils/spaces.dart';
import 'package:fluentui_system_icons/fluentui_system_icons.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class HomeView extends StatelessWidget {
  HomeView({super.key});

  List<String> tabs = [
    "Design",
    "Camping",
    "Surfing",
    "National Park",
    "Desert",
    "Countryside",
    "Villages",
    "Historical",
    "Seeside",
    "Travel",
  ];

  List<IconData> tabsIcons = [
    Icons.campaign,
    Icons.ac_unit,
    Icons.bathtub,
    Icons.cake,
    Icons.dark_mode,
    Icons.face,
    Icons.info,
    Icons.join_right,
    Icons.lan,
    Icons.mail,
    Icons.nat,
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          50.height,
          Container(
            width: 100.w,
            height: 55,
            margin: EdgeInsets.symmetric(horizontal: 16),
            padding: EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(40),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.6),
                  blurRadius: 5,
                ),
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Icon(FluentIcons.search_12_regular),
                    16.width,
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Where to?",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          "Anywhere, Any week, 2 guests",
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.normal,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                Container(
                  height: 35,
                  width: 35,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        blurRadius: 3,
                      ),
                    ],
                  ),
                  child: Icon(FluentIcons.alert_12_regular,size: 18,),
                ),
              ],
            ),
          ),
          Expanded(
            child: DefaultTabController(
              length: tabs.length,
              child: Column(
                children: [
                  Container(
                    height: 80,
                    child: TabBar(
                      unselectedLabelColor: Colors.grey,
                      isScrollable: true,
                      indicatorSize: TabBarIndicatorSize.label,
                      indicatorColor: Colors.black,
                      labelColor: Colors.black,
                      padding: EdgeInsets.all(16),
                      splashBorderRadius: BorderRadius.circular(50),
                      tabs: List.generate(
                        tabs.length,
                        (index) => Tab(
                          child: Column(
                            children: [
                              Icon(tabsIcons[index]),
                              Text(
                                tabs[index],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 15,
                    child: TabBarView(
                      children: [
                        ProductsListView(),
                        ProductsListView(),
                        ProductsListView(),
                        ProductsListView(),
                        ProductsListView(),
                        ProductsListView(),
                        ProductsListView(),
                        ProductsListView(),
                        ProductsListView(),
                        ProductsListView(),
                      ]
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: GestureDetector(
        onTap: () {
          Get.to(MapView());
        },
        child: Container(
          height: 55,
          width: 120,
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(40),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Map",
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
              6.width,
              Icon(
                Icons.map_rounded,
                color: Colors.white,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
