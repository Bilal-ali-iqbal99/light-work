import 'package:flutter/material.dart';
import 'package:location/location.dart';
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import 'package:permission_handler/permission_handler.dart';

class MapView extends StatelessWidget {
  MapView({super.key});

  MapboxMap? mapboxMap;

  Future currentLocation() async {
    Location location = Location();
    if (await Permission.location.request().isGranted) {
      if (await location.serviceEnabled()) {
        return await location.getLocation();
      } else {
        await location.requestService();
      }
    } else {
      await Permission.location.request();
    }
  }

  animateCamera({
    required MapboxMap mapboxMap,
    required Point point,
    required double zoom,
    required double pitch,
    required double bearing,
  }) async {
    mapboxMap.flyTo(
        CameraOptions(
          center: point.toJson(),
          zoom: zoom,
          pitch: pitch,
        ),
        MapAnimationOptions(duration: 2000, startDelay: 400));
  }

  onMapCreated(MapboxMap mapboxMap) {
    this.mapboxMap = mapboxMap;
    mapboxMap.compass.updateSettings(
      CompassSettings(
        enabled: false,
      ),
    );
    mapboxMap.style.setStyleURI(MapboxStyles.MAPBOX_STREETS);
    mapboxMap.scaleBar.updateSettings(ScaleBarSettings(enabled: false));

    mapboxMap.location.updateSettings(
      LocationComponentSettings(
        enabled: true,
        pulsingEnabled: true,
        puckBearingEnabled: true,
      ),
    );
    currentLocation().then((value) {
      animateCamera(
        mapboxMap: mapboxMap,
        point: Point(
          coordinates: Position(
            value.longitude!,
            value.latitude!,
          ),
        ),
        zoom: 13,
        pitch: 30,
        bearing: 0,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: MapWidget(
        resourceOptions: ResourceOptions(
            accessToken:
                "pk.eyJ1IjoiYmlsYWwtYWxpLWlxYmFsOTk5IiwiYSI6ImNsbTNxc2owYjQ3dXUza3BlbXA3a2FoYzEifQ.051xHuLERk_Zv_jqacgDvw"),
        onMapCreated: onMapCreated,
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(
          Icons.my_location_rounded,
          color: Theme.of(context).cardColor,
        ),
        onPressed: () {
          currentLocation().then((value) {
            animateCamera(
              mapboxMap: mapboxMap!,
              point: Point(
                coordinates: Position(
                  value.longitude!,
                  value.latitude!,
                ),
              ),
              zoom: 13,
              pitch: 30,
              bearing: 0,
            );
          });
        },
      ),
    );
  }
}
